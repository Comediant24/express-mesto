self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7ad2db8922c83f169810a7298b71f2e3",
    "url": "/mesto-react/index.html"
  },
  {
    "revision": "0582008d2d2d23c42196",
    "url": "/mesto-react/static/css/main.0df397a6.chunk.css"
  },
  {
    "revision": "9f3cfd6804ef5399afea",
    "url": "/mesto-react/static/js/2.e30102dc.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/mesto-react/static/js/2.e30102dc.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0582008d2d2d23c42196",
    "url": "/mesto-react/static/js/main.dfb02473.chunk.js"
  },
  {
    "revision": "6e04319a44e5e6859875",
    "url": "/mesto-react/static/js/runtime-main.36fb0e45.js"
  },
  {
    "revision": "09f4068bb74fc78ffbce74f5596d6aa5",
    "url": "/mesto-react/static/media/Inter-Black.09f4068b.woff2"
  },
  {
    "revision": "e37354838bf8078ac0d296217613533f",
    "url": "/mesto-react/static/media/Inter-Black.e3735483.woff"
  },
  {
    "revision": "35ee0c124d0e19a342243bcaa1ae2f48",
    "url": "/mesto-react/static/media/Inter-Medium.35ee0c12.woff2"
  },
  {
    "revision": "85f4b8e903fbd1d2c98a67dd0dca42e7",
    "url": "/mesto-react/static/media/Inter-Medium.85f4b8e9.woff"
  },
  {
    "revision": "4dd66a113d54a7f9a1ae913049610617",
    "url": "/mesto-react/static/media/Inter-Regular.4dd66a11.woff2"
  },
  {
    "revision": "7c539936c4c8c822b59a1bcc6c08a6ec",
    "url": "/mesto-react/static/media/Inter-Regular.7c539936.woff"
  },
  {
    "revision": "bdfb8ebb113b9312e080c2f4b4213223",
    "url": "/mesto-react/static/media/add-button.bdfb8ebb.svg"
  },
  {
    "revision": "34c4685038e8cf551566cb4ee96e20e5",
    "url": "/mesto-react/static/media/avatar-edit.34c46850.svg"
  },
  {
    "revision": "c2d0901f14de58acae456bda23f80e8a",
    "url": "/mesto-react/static/media/close-icon.c2d0901f.svg"
  },
  {
    "revision": "efa6fb04512d4ea565aaa4109835b46d",
    "url": "/mesto-react/static/media/delete.efa6fb04.svg"
  },
  {
    "revision": "0fa1c3696d696f562fdb745f4ef13d9e",
    "url": "/mesto-react/static/media/edit-button-s.0fa1c369.svg"
  },
  {
    "revision": "58afbe73d6547d1730a443f381c68d9e",
    "url": "/mesto-react/static/media/edit-button.58afbe73.svg"
  },
  {
    "revision": "6c74d9b53442a247e20750f5de0be939",
    "url": "/mesto-react/static/media/like.6c74d9b5.svg"
  },
  {
    "revision": "9fdebb6b009c16af50fae58657e30a94",
    "url": "/mesto-react/static/media/like_true.9fdebb6b.svg"
  },
  {
    "revision": "855a8c9865e79463f31e74f9abcb4438",
    "url": "/mesto-react/static/media/logo.855a8c98.svg"
  }
]);